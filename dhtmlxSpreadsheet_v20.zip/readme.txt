dhtmlxSpreadsheet v.2.0 build 121026

This software is allowed to use:

- in GPL project for free
- in non-GPL project you need to obtain Commercial or Enterise License (both include official technical support)

Please contact sales@dhtmlx.com for details

System Requirements:
--------------------------
- on client side: IE6+, FF, Chrome, Safari, Opera
- on server side: PHP 5.x, MySQL

Installation:
--------------------------
1. Unpack archive content to the directory you'd like to install dhtmlxSpreadsheet
2. Load index.php in your browser using http path to directory above (for example: http://www.yoursite.com/spreadsheet/index.php) and fill in the form with mySQL connection parameters there.

For CMS plugins see installation instructions see documentation:
http://docs.dhtmlx.com/doku.php?id=dhtmlxspreadsheet:plugin

Online Documentation:
--------------------------
http://docs.dhtmlx.com/doku.php?id=dhtmlxspreadsheet:start

Samples:
--------------------------
[package]/samples

(c) Dinamenta, UAB